<div id="nav">
			<table align="center" class="navlinks">
				<tr>
					<td><a href="index.php" class="navigation">HOME</a></td>
					<td><a href="admission.php" class="navigation">ADMISSION</a></td>
					<td><a href="programs.php" class="navigation">PROGRAMS</a></td>
					<td><a href="exams.php" class="navigation">EXAMINATIONS</a></td>
					<td><a href="campus.php" class="navigation">LIFE ON CAMPUS</a></td>
					<td><a href="about.php" class="navigation">ABOUTS US</a></td>
				</tr>
			</table>
		</div>
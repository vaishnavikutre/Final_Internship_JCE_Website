<div id="footer">
    <p style="color:white;font-size:14px;margin-left:10px; padding-top:15px;">Copyright &copy; <a
            href="http://tanzamo.com" style='color:white;'>Jain college of Engineering Belgaum.</a></p>
</div>
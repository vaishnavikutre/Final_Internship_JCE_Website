-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 28, 2014 at 12:21 PM
-- Server version: 5.6.12-log
-- PHP Version: 5.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `collegeWebsite`
--
CREATE DATABASE IF NOT EXISTS `collegeWebsite` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `collegeWebsite`;

-- --------------------------------------------------------

--
-- Table structure for table `application`
--

CREATE TABLE IF NOT EXISTS `application` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(30) NOT NULL,
  `middlename` varchar(30) NOT NULL,
  `surname` varchar(30) NOT NULL,
  `phone` int(20) NOT NULL,
  `email` varchar(300) NOT NULL,
  `programme` varchar(100) NOT NULL,
  `education` varchar(50) NOT NULL,
  `mathematics` text NOT NULL,
  `physics` text NOT NULL,
  `chemistry` text NOT NULL,
  `biology` text NOT NULL,
  `english` text NOT NULL,
  `certificate` varchar(50) NOT NULL,
  `relationship` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `application`
--

INSERT INTO `application` (`id`, `firstname`, `middlename`, `surname`, `phone`, `email`, `programme`, `education`, `mathematics`, `physics`, `chemistry`, `biology`, `english`, `certificate`, `relationship`) VALUES
(1, 'florian', 'ephraim', 'kipeta', 654507180, 'florianephraim@gmail.com', 'Computer Science', 'form four', 'D', 'D', 'D', 'D', 'D', 'note.txt', 'Married'),
(2, 'Agatha', 'Ephraim', 'kipeta', 654507180, 'agathakipeta@gmail.com', 'Civil Engineering', 'form four', 'A', 'A', 'A', 'A', 'A', 'projects.txt', 'Single'),
(4, 'Felix', 'Ephraim', 'Kipeta', 654507180, 'felixangelo@gmail.com', 'Telecommunication Engineering', 'Form six', 'A', 'A', 'A', 'A', 'A', 'wampmanager.exe', 'Single'),
(5, 'Faraja', 'J', 'January', 98765556, 'faraja12@gmail.com', 'Mechanical ENgineering', 'form four', 'A', 'A', 'A', 'A', 'A', 'tabley.jpg', 'Single');

-- --------------------------------------------------------

--
-- Table structure for table `contents`
--

CREATE TABLE IF NOT EXISTS `contents` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `full_contents` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=30 ;

--
-- Dumping data for table `contents`
--

INSERT INTO `contents` (`id`, `full_contents`) VALUES
(1, 'Welcome to Jain College of Engineering,Belgaum.'),
(2, 'Admissions open for the year 2021-22.<br>CET CODE-BE:E196,MBA:E190'),
(3, 'Under Graduate Courses Offered<br>Sl. No &nbsp;	Course &nbsp;	Level	&nbsp;Sanctioned Intake<br><br>1	Civil Engineering	Under Graduate	90<br>2	Computer Science Engineering	Under Graduate	60<br>3	Electronics & Communication Engineering	Under Graduate	180<br>4	Electrical & Electronics Engineering	Under Graduate	60<br>5	Mechanical Engineering	Under Graduate	120<br>Post Graduate Courses Offered<br><br>Sl. No &nbsp;	Course &nbsp;	Level	&nbsp;Sanctioned Intake<br>1	Master of Business Administration	Post Graduate	120<br>2	Master of Computer Applications	Post Graduate	60<br>3	M. Tech in Construction Technology	Post Graduate	24<br>Doctrol Courses Offered / Research Centers at JCE<br><br>Sl. No &nbsp;	Research  &nbsp; Center &nbsp;	Level<br>1	Computer Science & Engineering	Ph.D<br>2	Civil Engineering	Ph.D<br>3	Electronics & Communication Engineering	Ph.D<br>4	Electrical & Electronics Engineering	Ph.D<br>5	Mechanical Engineering	Ph.D6	Mathematics	Ph.D'),
(4, 'Exams are near..'),
(5, ' Campus Lifestyle<br><br>  It is a diverse community of students at JCE, and  the activities on offer are as diverse and varied too.  From entertainment to extra-curricular or even religious  pursuits, there is never a dull moment on campus. There is never  a dull moment on campus, as the activities on offer are as diverse and  varied too - from entertainment to extra-curricular or even religious pursuits.<br><br>  Student Affairs<br><br>  All activity related to extracurricular programs,  forums, clubs, community service, and entrepreneurship  cell and students council are managed by the JCE.'),
(6, 'Who We Are<br>JAIN Group is an established education provider and entrepreneurship incubator in India.<br>Education is at the forefront of JAIN Group is identity. Over the years, it has been synonymous with imparting quality education in India from the kindergarten to the postgraduate level. The various educational institutions functioning under the banner of JAIN Group are testaments of its commitment towards education. Jain College, Jain (Deemed-to-be University), Jain International Residential School, Jain Heritage Schools, and Jain Vidyaniketan are some of the many accomplishments of JAIN Group in the education sector. Quality research is another aspect that has always been in the JAIN Group mandate.<br><br>'),
(7, 'Contact us:<br><p>Jain College of Engineering,Belgaum.<br>599/2, T.S. Nagar Hunchanhatti Road Macche Belagavi 590014<br>'),
(8, 'Add something'),
(9, 'Add something'),
(10, 'Collect the application form and prospectus in person by paying Rs. 500/- at the admission office (Address : Jain College of Engineering Belagavi, 599/2, T.S. Nagar Huncahanatti Road Macche Belagavi) and submit the duly filled Form at the Office.<br>For any Clarification, Please Contact us at – 0831-2411192 / 9342997171 You can also write to us at info@jainbgm.in<br>'),
(11, 'Application form will be uploaded soon....'),
(12, 'Jain College of Engineering (JCE), Belagavi was started under the umbrella of Jain Group of Institutions (JGI) headquartered in Bangalore. JCE made its beginning in the year 2010 in the disciplines of Civil Engineering, Computer Science and Engineering, Electrical and Electronics Engineering, Electronics and Communication Engineering as well as Mechanical Engineering. All the courses are affiliated to Visvesvaraya Technological University, Belagavi and our institute is also affiliated to AICTE, New-Delhi.<br><br>Apart from these engineering courses, the institute also has an Post Graduate Courses, namely M.Tech in Power Systems and Construction Technology, MBA and MCA. Our students have been performing consistently in their academics with about 65% of them scoring a distinction in all their semesters till date. A few students have brought laurels to our institute by being nominated as “University Blues” in various sports fields.'),
(13, 'Add something'),
(14, 'you can visit the following page:<br>For Examination Regulation visit <a href="examination_reg.php"><i>Here</i></a><br>For Appearing visit <a href="appear_exams.php"><i>Here</i>'),
(15, 'In order to appeal Examination you need to follow the following procedure:<br><ol><li>Fill the application form from the registrar office</li><li>Pay appearing fee to the Bursar office</li><li>Wait for your result</li></ol>'),
(16, 'Prospect will be uploaded soon....'),
(17, 'Policy'),
(18, 'Our college provide scholarship for girl only who want to study Engineering field.</br>This scholarship include<ol>'),
(19, 'Laboratories<br>JCE BIOTECHNOLOGY designs and manufactures a wide range of isolators that can be personalised and custom-configured to ensure the prevention of all contamination risks, provide seamless product, animal and micro-organism containment and protect personnel during handling operations in laboratories and research institutes.'),
(20, 'About Our University<br>As one of the world is premier academic and research institutions, the Modern University has driven new ways of thinking since our founding. Today, we represent an intellectual destination that draws inspired scholars to our local and international campuses, keeping us at the nexus of ideas that challenge and change the world and provide companies with new specialists.'),
(21, 'IEEE Program<br>NSS Red Cross<br>LEAD'),
(22, 'Jain College of Engineering (JCE), Belagavi was started under the umbrella of Jain Group of Institutions (JGI) headquartered in Bangalore. JCE made its beginning in the year 2010 in the disciplines of Civil Engineering, Computer Science and Engineering, Electrical and Electronics Engineering, Electronics and Communication Engineering as well as Mechanical Engineering. All the courses are affiliated to Visvesvaraya Technological University, Belagavi and our institute is also affiliated to AICTE, New-Delhi.'),
(23, 'DXC<br>Happy to announce Engineering 2022 Hiring results.<br>CTC: 4LPA<br>Total selects - 29<br><br>Brillio<br>Happy to announce Engineering 2022 Hiring results.<br>CTC: 7.50 LPA plus Bonus -INR 4 Lakh a total of 11LPA<br>Profile: Engineer<br>Selects: 2<br>Branch – CSE<br><br>Cognizant<br>Happy to announce Engineering 2022 Hiring results.<br>Designation : Gen C Next<br>CTC : 6.75LPA<br>Total selects – 2<br>Dept – CSE<br>'),
(24, 'Phone: +91 831 2411192<br>#599/2 T.S. Nagar Hunchanhatti Road<br>Macche Belagavi 590014<br>Email: info@jainbgm.in<br>'),
(25, 'Medical'),
(26, 'This is news page'),
(27, 'Result'),
(28, 'Timetable'),
(29, 'Graduation day comming soon');

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE IF NOT EXISTS `news` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `heading` varchar(400) NOT NULL,
  `full_news` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `heading`, `full_news`) VALUES
(1, 'JCE Gokart Team – Quick Shifters & team participated in four national karting championships.', 'In 2018 started JCE Gokart Team – Quick Shifters & team participated in four national karting championships. Won prizes worth more than 1.25 Lakhs on 27/03/2019.'),
(2, 'IEEE DAY 2020 Celebration', 'IEEE DAY 2020 Celebration, Cake Cutting by Dean Prof P.Y Chitti, Dr. Krupa Rasane (Head EC, Senior IEEE Member, Branch Counsellor) IEEE Student Execom members and Branch Staff Co-ordinators Prof. Sushma and Prof. Zuhi on 6/10/2020.'),
(3, 'HACKitON 3days Workshop.', 'HackITon goal was to bring out the creativity of the students and boost their confidence. The students were expected to solve some of the complex problem statements in the span of just 3 days.'),
(4, 'Connect to Careers 2019- 2020', 'Jain College of Engineering Belagavi has been undertaking a very unique campaign called ‘Connect To Careers’ since 2016 with the main aim of ‘enhancing employability’ concept. As a part of this initiative, we organize a Job Fair to provide placement assistance to Under-Graduate and Post-Graduate Students across all streams.'),
(5, 'DXC Technology Launch Program', 'DXC Technology Launch Program in association with ICT Academy was inaugurated on 28/08/2021 at Jain College of Engineering, Belagavi by Dr. K G Vishwanath – Principal & Director Jain College of Engineering, Belagavi.');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `password`) VALUES
(1, 'Vaishnavi', 'krishnasadan'),
(2, 'kipeta', 'atcict'),
(3, 'gasto', 'kipeta'),
(4, 'Elimbingi', 'qwerty'),
(5, 'Nathan', 'nathan'),
(6, 'Felix', 'felix'),
(7, 'john', 'kisiri');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<div id="left">
	<div class="one">
		<b class="title">ADMISSION</b>
		<hr>
		<table align="center" width="100%" class="news">
			<tr>
			   <td>&nbsp; <img src="img/news.png">&nbsp;&nbsp;&nbsp; <a href="online.php" target='_blank' class="admissionlinks">Apply Online</a></td>
			</tr>
			<tr>
				<td>&nbsp; <img src="img/news.png">&nbsp;&nbsp;&nbsp; <a href="requirements.php" class="admissionlinks">Entry Requirement</a></td>
			</tr>
			<tr>
				<td>&nbsp; <img src="img/news.png">&nbsp;&nbsp;&nbsp; <a href="download_form.php" class="admissionlinks">Download Form</a></td>
			</tr>
			<tr>
				<td>&nbsp; <img src="img/news.png">&nbsp;&nbsp;&nbsp; <a href="reguration.php" class="admissionlinks">About JCE</a></td>
			</tr>
		</table>
	</div>
	<div class="two">
		<b class="title">CAMPUS TOUR</b>
		<hr>
		<table align="center" width="100%" class="news">
			<tr>
			   <td>&nbsp; <img src="img/news.png">&nbsp;&nbsp;&nbsp; <a href="laboratories.php" class="admissionlinks">Laboratories</a></td>
			</tr>
			<tr>
				<td>&nbsp; <img src="img/news.png">&nbsp;&nbsp;&nbsp; <a href="computers.php" class="admissionlinks">About our University</a></td>
			</tr>
			<tr>
				<td>&nbsp; <img src="img/news.png">&nbsp;&nbsp;&nbsp; <a href="workshop.php" class="admissionlinks">Our Programs</a></td>
			</tr>
			<tr>
				<td>&nbsp; <img src="img/news.png">&nbsp;&nbsp;&nbsp; <a href="library.php" class="admissionlinks">Why choose us</a></td>
			</tr>
			<tr>
				<td>&nbsp; <img src="img/news.png">&nbsp;&nbsp;&nbsp; <a href="hostel.php" class="admissionlinks">Placement</a></td>
			</tr>
			<tr>
				<td>&nbsp; <img src="img/news.png">&nbsp;&nbsp;&nbsp; <a href="canteen.php" class="admissionlinks">Contact</a></td>
			</tr>
			
		</table>
	</div>
</div>
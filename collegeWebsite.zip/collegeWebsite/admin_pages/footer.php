<div id="footer">
	<p style="color:white;font-size:14px;margin-left:10px; padding-top:15px;">Copyright &copy; Jain College of Engineering,Belgaum.</a></p>
</div>
<?php
$conn=mysqli_connect('localhost','root','','collegeWebsite');
if (!$conn) {
	echo "You are not connected to the database";
}
?>
<p>This Jain college of engineering,Belgaum website.</p>
<p>This College Website was developed usig PHP, MySQL Database, HTML, and CSS. This project is a content management system for a certain school which means the content of the website are dynamic and can be easily updated on the admin side.</p>

<h2>Features/Pages</h2>
<strong>Admin Side</strong>
<ul>
	<li><strong>Update Contents for th ff pages/panel:</strong><br>
		<ul>
			<li><strong>Home</strong></li>
			<li><strong>Admission</strong></li>
			<li><strong>Program</strong></li>
			<li><strong>Exams</strong></li>
			<li><strong>Campus</strong></li>
			<li><strong>About</strong></li>
			<li><strong>Contact</strong></li>
			<li><strong>News and Events</strong></li>
			<li><strong>Entry Requirements</strong></li>
			<li><strong>and manay more.</strong></li>
		</ul>
	</li>
	<li><strong>Application List</strong></li>
	<li><strong>Users Management</strong></li>
</ul>
Admin name: Vaishnavi
Password: krishnasadan
 Database name: collegeWebsite it located inside the folder.

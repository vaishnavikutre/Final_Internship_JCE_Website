<div id="wrapper">
	<div id="header">
		<div class="box1">
			<marquee scrollamount="2">
				<h2 align="center" class="mar">Welcome to Jain College of Engineering</h2>
			</marquee>
		</div>
		<div class="box2">
			<table align="center" class="headlinks">
				<tr>
					<td><a href="login.php" class="head_links">Admin Login</a></td>
				</tr>
			</table>
		</div>
	</div>
<?php
$conn=mysqli_connect('localhost','root','',"collegeWebsite");
if (!$conn) {
	echo "Your not connected to the database".mysqli_error();
}


?>